# Variance 10K
This test is the incompressible counterpart to *200K Lines*.

Where the 200K test repeats the same string 200 thousand times - letting compression collapse 4.2Mb of HTML down to almost nothing - this page serves *10 thousand* paragraphs of randomly-ordered words plus a random numeric suffix. Compression cannot save anyone here: the payload is incompressible by construction, so what you are measuring is raw render, serialization and transfer throughput, not deflate wizardry.

Determinism: the content is generated with a seeded PRNG (`mulberry32`, seed `1337`) over a shared 64-word list, using *identical generator code in both frameworks*. This means:

- Every request returns the same content (stable sizes, no statistical noise from varying payloads).
- Both frameworks render **byte-identical paragraph content** - all 10,000 entries checksum-match across frameworks. The full documents still differ in size, because Next.JS additionally embeds its serialized flight payload (see 200K Lines).

The page is rendered dynamically on every request (`isDynamic = true` / `force-dynamic`).

Resulting sizes: Elegance renders a 0.69 Mb HTML document (200 KB transferred over Brotli), Next.JS a 2.49 Mb document (592 KB transferred over GZIP).

Developer Notes:
We originally ran this test with *50 thousand* paragraphs (~12.5 Mb of HTML on both sides). Elegance completed the run (15.8 rps at `-c 50`), but Next.JS could not finish a *single* request inside the 30 second window - all 50 connections were aborted at the deadline with zero completed responses. We re-scaled to 10K so both frameworks produce comparable numbers. Draw your own conclusions.

Code (abbreviated - the full generator is identical in both projects):
```tsx
// Elegance (pages/page.tsx) & Next.JS (app/page.tsx)
function mulberry32(a: number) {
    return function () {
        a |= 0; a = (a + 0x6D2B79F5) | 0;
        let t = Math.imul(a ^ (a >>> 15), 1 | a);
        t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
        return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
    };
}

export default function Page() {
    const rand = mulberry32(1337);
    const paras: string[] = [];
    for (let i = 0; i < 10000; i++) {
        let s = "";
        for (let w = 0; w < 8; w++) s += (w ? " " : "") + WORDS[Math.floor(rand() * WORDS.length)];
        s += " #" + Math.floor(rand() * 1000000);
        paras.push(s);
    }

    return <div>
        <h1>Variance Testing.</h1>
        {paras.map(p => <p>{p}</p>)}
    </div>;
}

// Elegance: export const isDynamic = true;
// Next.JS: export const dynamic = 'force-dynamic'
```

## On transfer sizes
Since the paragraph content is identical, differences in `Bytes / request` come from each framework's out-of-the-box compression defaults (Elegance ships Brotli, Next.JS ships GZIP) and from the flight payload Next.JS appends. On incompressible content Brotli still maintains a large lead over GZIP, which is exactly what makes this comparison interesting.
