# Hello World
This test attempts to measure raw RPS (requests-per-second) with a minimal static page.

The page code looks as follows:

```tsx
// Next.JS & Elegance: /pages/page.tsx
export default function page() {
    return <div>
        <h1>Hello World!</h1>
    </div>
}
```

## Elegance 
- Prod mode uses -prod flag
- Dev mode uses -dev flag

## Next.JS
- Production mode test uses `output: "standalone"` in `next.config.ts`, and was executed with `node .next/standalone/server.js`.