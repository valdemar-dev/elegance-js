# RPS Test
This test is meant to measure raw RPS (requests-per-second) by simulating a primitive GET endpoint that returns `{"message": "Hello, World!", }`.

Both frameworks return the exact same paylod, so the only factor which affects RPS is raw framework level overhead and optimizations.

Code:
```tsx
// Elegance: /pages/api/route.ts
import type { IncomingMessage, ServerResponse } from "node:http";

export async function GET(req: IncomingMessage, res: ServerResponse) {
    res.end(JSON.stringify({ message: "Hello, World!", }));
}

// Next.JS: /pages/api/route.ts
export async function GET() {
    const res = new Response(JSON.stringify({ message: "Hello, World!", }));

    return res;
}
```