# SSR Test
This test aims to measure how fast both frameworks can render a dynamic server-rendered page.

For next, this involves `force-dynamic` to ensure the result isn't cached.

On both pages, we read some request headers, and embed them into the response.

Code:
```tsx
// Next.JS: /pages/page.ts
import { headers } from 'next/headers'

export const dynamic = 'force-dynamic'

export default async function page() {
    const h = await headers()
    const headerValue = h.get('accept-encoding');

    return <div>{headerValue}</div>
}

// Elegance: /pages/page.ts
import type { IncomingMessage, } from "node:http";

export default function page({ req, }: { req: IncomingMessage }) {
    const headerValue = req.headers["accept-encoding"]; 

    return <div>{headerValue}</div>;
}

export const isDynamic = true;
```