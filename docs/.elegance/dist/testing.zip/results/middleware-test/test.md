# Middleware Test
This test measures the cost of passing every request through a middleware layer.

The endpoint is *identical* to the one in the Raw API RPS test - a GET returning `{"message": "Hello, World!"}` - except a global middleware runs before it and attaches a single response header (`x-bench-middleware: 1`). No logging, no async work, no cookies: just the pipeline itself.

Read the result next to the **Raw API RPS** card (same endpoint, no middleware, same methodology and machine state): the delta between the two is the per-request middleware overhead.

Code:
```ts
// Elegance: /pages/middleware.ts
import type { IncomingMessage, ServerResponse } from "node:http";

export default async function middleware(
    req: IncomingMessage,
    res: ServerResponse,
    next: () => Promise<void>,
) {
    res.setHeader("x-bench-middleware", "1");
    await next();
}
```

```ts
// Next.JS: /proxy.ts  (Next 16's convention, replaces middleware.ts)
import { NextResponse } from "next/server";
import type { NextRequest } from "next/server";

export function proxy(req: NextRequest) {
    const res = NextResponse.next();
    res.headers.set("x-bench-middleware", "1");
    return res;
}

export const config = {
    matcher: "/api/:path*",
};
```

Both were verified to actually run during the test: the `x-bench-middleware: 1` header is present on every response.
