All tests were run on a machine running with:
- CachyOS Linux (Arch-based, rolling) x86_64
- Linux 7.2.0-1-cachyos
- Hyprland (Wayland)
- AMD Ryzen 7 255 (8 cores / 16 threads) @ up to 4.97 GHz boost
- 16 GB RAM
- Node v26.7.0
- Next.JS 16.1.6 (Turbopack, standalone output)
- elegance-js 3.2.0 (local build)

`oha` (v1.16.0) is used for the actual stress-testing tool.

Two of the tests deserve a note on fairness: the *Variance 10K* page generates its content with a seeded PRNG (`mulberry32`, seed `1337`) over a shared 64-word list, using identical generator code in both frameworks - so both render byte-identical paragraph content on every request, and the payload is incompressible by construction. The *Middleware* test uses an endpoint identical to the Raw API RPS test with one no-op global middleware attached; read its numbers against the Raw API RPS card for the per-request middleware overhead. For Next.JS this uses the `proxy.ts` convention (Next 16's replacement for `middleware.ts`), for Elegance `pages/middleware.ts`.

To ensure performance and memory availability was fair, each server was freshly started for its run - and we stopped each server before we tested the other one. The machine was plugged in with the CPU governor and EPP set to `performance` for every run.

It's also important to note, that whilst Elegance by default uses all available threads in production mode, we used only 1 worker (`-w=1`), as most test results scale linearly with worker count; and this way it's more comparable to the Next server.

For all tests, we ran `-c 50 -z 10` for warmup, and `-c 50 -z 30` for the actual test.
