All tests were run on a machine running with:
- Debian GNU/Linux 13 (trixie) x86_64
- Linux 6.12.88+deb13-amd64
- GNOME 48.7
- AMD Ryzen 5 3600 (12) @ 4.21 GHz
- 16Gb DDR4 3200Mhz CL16

`oha` is used for the actual stress-testing tool.

To ensure performance and memory availability was fair, all tests were run after a fresh reboot - and we stopped each server during the test before we tested the other one.

It's also important to note, that whilst Elegance by default uses all available threads in production mode, we used only 1 worker, as most test results scale linearly with worker count; and this way it's more comparable to the Next server.

For all tests, we ran `-c 50 -z 10` for warmup, and `-c 50 -z 30` for the actual test.
