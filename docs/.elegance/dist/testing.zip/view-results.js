const fs = require('fs');
const path = require('path');

const c = {
    reset: '\x1b[0m',
    bold: '\x1b[1m',
    dim: '\x1b[2m',
    white: '\x1b[97m',
    gray: '\x1b[90m',
    cyan: '\x1b[96m',
    green: '\x1b[92m',
    yellow: '\x1b[93m',
    red: '\x1b[91m',
    blue: '\x1b[94m',
    magenta: '\x1b[95m',
    bgDark: '\x1b[48;5;235m',
    bgRow: '\x1b[48;5;236m',
    bgRowAlt: '\x1b[48;5;234m',
};

const paint = (...parts) => parts.join('') + c.reset;
const bold = s => paint(c.bold, s);
const dim = s => paint(c.dim, c.gray, s);
const cyan = s => paint(c.cyan, s);
const green = s => paint(c.bold, c.green, s);
const yellow = s => paint(c.bold, c.yellow, s);
const red = s => paint(c.red, s);
const gray = s => paint(c.gray, s);

const ms = v => (v * 1000).toFixed(2);
const num = v => Number(v).toFixed(2);
const mb = v => (v / 1024 / 1024).toFixed(2);
const sum = obj => Object.values(obj || {}).reduce((a, b) => a + b, 0);
const pad = (s, n, right = false) => {
    const str = String(s);
    const spaces = Math.max(0, n - stripAnsi(str).length);
    return right ? ' '.repeat(spaces) + str : str + ' '.repeat(spaces);
};

const stripAnsi = s => s.replace(/\x1b\[[0-9;]*m/g, '');

const args = process.argv.slice(2);
const flags = new Set(args.filter(a => a.startsWith('-')).map(a => a.toLowerCase()));
const title = args.find(a => !a.startsWith('-'));

const SECTION_FLAGS = {
    Throughput: ['-rps', '-throughput'],
    Latency: ['-lat', '-latency'],
    Reliability: ['-rel', '-reliability'],
};
const anySection = Object.values(SECTION_FLAGS).flat().some(f => flags.has(f));
const showGroup = label =>
    !anySection ||
    (SECTION_FLAGS[label] || []).some(f => flags.has(f));

if (!title) {
    const resultsRoot = path.join(__dirname, 'results');
    if (!fs.existsSync(resultsRoot)) {
        console.error('No results/ directory found.');
        process.exit(1);
    }

    const folders = fs.readdirSync(resultsRoot)
        .filter(f => fs.statSync(path.join(resultsRoot, f)).isDirectory())
        .sort((a, b) => {
            const ta = fs.statSync(path.join(resultsRoot, a)).mtimeMs;
            const tb = fs.statSync(path.join(resultsRoot, b)).mtimeMs;
            return ta - tb; // oldest first
        });

    if (folders.length === 0) {
        console.error('No result folders found in results/');
        process.exit(1);
    }

    console.log('');
    console.log(paint(c.bold, c.white, '  ▸ available benchmarks'));
    console.log(gray('  ─'.repeat(28)));

    for (const folder of folders) {
        const mtime = fs.statSync(path.join(resultsRoot, folder)).mtime;
        const dateStr = mtime.toISOString().slice(0, 10);
        console.log('');
        console.log('  ' + paint(c.bold, c.cyan, folder) + '  ' + gray(dateStr));

        const mdPath = path.join(resultsRoot, folder, 'test.md');
        if (fs.existsSync(mdPath)) {
            const preview = fs.readFileSync(mdPath, 'utf8')
                .split('\n')
                .filter(l => l.trim() !== '')
                .slice(0, 3);
            for (const line of preview) {
                const stripped = line.replace(/^#+\s*/, '').replace(/\*\*/g, '');
                console.log('    ' + gray(stripped));
            }
        }
    }

    console.log('');
    console.log(gray('  Usage: node view-results.js <title> [-rps] [-lat] [-rel]'));
    console.log('');
    process.exit(0);
}

const outDir = path.join('results', title);
if (!fs.existsSync(outDir)) {
    console.error(`No results folder found at: ${outDir}`);
    process.exit(1);
}

const files = fs.readdirSync(outDir).filter(f => f.endsWith('.json'));
const runNames = [...new Set(
    files
        .map(f => f.match(/^(?:elegance|next)-(.+)\.json$/)?.[1])
        .filter(Boolean)
)].sort((a, b) => {

    const pathA = path.join(outDir, `elegance-${a}.json`);
    const pathB = path.join(outDir, `elegance-${b}.json`);
    const mtA = fs.existsSync(pathA) ? fs.statSync(pathA).mtimeMs : 0;
    const mtB = fs.existsSync(pathB) ? fs.statSync(pathB).mtimeMs : 0;
    return mtA - mtB;
});

if (runNames.length === 0) {
    console.error(`No result JSON files found in: ${outDir}`);
    process.exit(1);
}

const GROUPS = [
    {
        label: 'Throughput',
        metrics: [
            { label: 'Requests / sec', eVal: e => num(e.summary.requestsPerSec), nVal: n => num(n.summary.requestsPerSec), higherIsBetter: true },
            { label: 'RPS mean', eVal: e => num(e.rps.mean), nVal: n => num(n.rps.mean), higherIsBetter: true },
            { label: 'RPS cv%', eVal: e => num((e.rps.stddev / e.rps.mean) * 100), nVal: n => num((n.rps.stddev / n.rps.mean) * 100), higherIsBetter: false },
            { label: 'Throughput MB/s', eVal: e => mb(e.summary.sizePerSec), nVal: n => mb(n.summary.sizePerSec), higherIsBetter: true },
            { label: 'Bytes / request', eVal: e => e.summary.sizePerRequest, nVal: n => n.summary.sizePerRequest, higherIsBetter: null },
        ],
    },
    {
        label: 'Latency',
        metrics: [
            { label: 'Average', eVal: e => ms(e.summary.average), nVal: n => ms(n.summary.average), higherIsBetter: false },
            { label: 'Fastest', eVal: e => ms(e.summary.fastest), nVal: n => ms(n.summary.fastest), higherIsBetter: false },
            { label: 'Slowest', eVal: e => ms(e.summary.slowest), nVal: n => ms(n.summary.slowest), higherIsBetter: false },
            { label: 'p50', eVal: e => ms(e.latencyPercentiles.p50), nVal: n => ms(n.latencyPercentiles.p50), higherIsBetter: false },
            { label: 'p75', eVal: e => ms(e.latencyPercentiles.p75), nVal: n => ms(n.latencyPercentiles.p75), higherIsBetter: false },
            { label: 'p90', eVal: e => ms(e.latencyPercentiles.p90), nVal: n => ms(n.latencyPercentiles.p90), higherIsBetter: false },
            { label: 'p95', eVal: e => ms(e.latencyPercentiles.p95), nVal: n => ms(n.latencyPercentiles.p95), higherIsBetter: false },
            { label: 'p99', eVal: e => ms(e.latencyPercentiles.p99), nVal: n => ms(n.latencyPercentiles.p99), higherIsBetter: false },
            { label: 'p99.9', eVal: e => ms(e.latencyPercentiles['p99.9']), nVal: n => ms(n.latencyPercentiles['p99.9']), higherIsBetter: false },
        ],
    },
    {
        label: 'Reliability',
        metrics: [
            { label: 'Success rate %', eVal: e => num(e.summary.successRate * 100), nVal: n => num(n.summary.successRate * 100), higherIsBetter: true },
            { label: 'Total requests', eVal: e => sum(e.statusCodeDistribution), nVal: n => sum(n.statusCodeDistribution), higherIsBetter: true },
            { label: 'Errors', eVal: e => sum(e.errorDistribution), nVal: n => sum(n.errorDistribution), higherIsBetter: false },
        ],
    },
];

const W_LABEL = 16;
const W_VAL = 12;
const W_UNIT = 6;
const W_DELTA = 12;
const TOTAL = W_LABEL + W_VAL + W_VAL + W_UNIT + W_DELTA + 8;

const HR = gray('─'.repeat(TOTAL));
const THICK = gray('━'.repeat(TOTAL));

function printHeader(runName) {
    console.log('');
    console.log(THICK);
    console.log(
        paint(c.bold, c.cyan, `  ${runName}`)
    );
    console.log(THICK);

    console.log(
        '  ' +
        pad(gray('metric'), W_LABEL) + '  ' +
        pad(cyan('elegance'), W_VAL, true) + '  ' +
        pad(cyan('next'), W_VAL, true) + '  ' +
        pad(gray('unit'), W_UNIT) + '  ' +
        pad(gray('winner'), W_DELTA, true),
    );
    console.log(HR);
}

function printGroup(label) {
    console.log('  ' + paint(c.bold, c.magenta, label.toUpperCase()));
}

function printMetric(metric, e, n) {
    const eRaw = String(metric.eVal(e));
    const nRaw = String(metric.nVal(n));
    const eV = parseFloat(eRaw);
    const nV = parseFloat(nRaw);
    const hib = metric.higherIsBetter;

    const eColor = hib === null ? c.white : (hib ? (eV >= nV ? c.green : c.red) : (eV <= nV ? c.green : c.red));
    const nColor = hib === null ? c.white : (hib ? (nV >= eV ? c.green : c.red) : (nV <= eV ? c.green : c.red));

    let unitStr = '';
    if (metric.label.includes('MB/s')) unitStr = 'MB/s';
    else if (metric.label.includes('Bytes')) unitStr = 'B';
    else if (metric.label.includes('cv%') || metric.label.includes('%')) unitStr = '%';
    else if (metric.label.includes('sec') || metric.label.includes('RPS')) unitStr = 'rps';
    else if (!metric.label.includes('Error') && !metric.label.includes('Total') && !metric.label.includes('request')) unitStr = 'ms';

    let deltaStr = '';
    if (hib !== null && eV > 0 && nV > 0 && eV !== nV) {
        const winner = hib ? (eV > nV ? 'elegance' : 'next') : (eV < nV ? 'elegance' : 'next');
        const ratio = hib
            ? (eV > nV ? eV / nV : nV / eV)   // higher-is-better: winner / loser
            : (eV < nV ? nV / eV : eV / nV);  // lower-is-better:  loser  / winner (how much worse the loser is)
        const winColor = winner === 'elegance' ? c.green : c.yellow;
        deltaStr = paint(c.bold, winColor, `${winner} ${ratio.toFixed(2)}x`);
    } else if (hib === null) {
        deltaStr = gray('—');
    } else {
        deltaStr = gray('tie');
    }

    console.log(
        '  ' +
        pad(gray(metric.label), W_LABEL) + '  ' +
        paint(c.bold, eColor, pad(eRaw, W_VAL, true)) + '  ' +
        paint(c.bold, nColor, pad(nRaw, W_VAL, true)) + '  ' +
        pad(gray(unitStr), W_UNIT) + '  ' +
        pad(deltaStr, W_DELTA, true),
    );
}

function renderInline(text) {
    return text
        .split(/(`[^`]+`|\*\*[^*]+\*\*)/)
        .map((part, i) => {
            if (part.startsWith('**') && part.endsWith('**')) return paint(c.bold, c.white, part.slice(2, -2));
            if (part.startsWith('`') && part.endsWith('`')) return paint(c.bold, c.yellow, part.slice(1, -1));
            return gray(part);
        })
        .join('');
}

function printMd(mdPath, heading) {
    if (!fs.existsSync(mdPath)) return;

    const lines = fs.readFileSync(mdPath, 'utf8').split('\n');

    console.log('');
    console.log(THICK);
    console.log(paint(c.bold, c.cyan, '  ▸ ') + paint(c.bold, c.white, heading));
    console.log(THICK);

    let prevBlank = false;
    let inBlock = false;
    for (const raw of lines) {
        const line = raw.trimEnd();

        if (/^```/.test(line)) {
            if (!inBlock) {
                console.log('');
                inBlock = true;
            } else {
                console.log('');
                inBlock = false;
            }
            prevBlank = false;
            continue;
        }

        if (inBlock) {
            console.log('    ' + paint(c.yellow, line));
            prevBlank = false;
            continue;
        }

        if (/^# /.test(line)) {
            console.log('');
            console.log('  ' + paint(c.bold, c.white, line.slice(2)));
            prevBlank = false;

        } else if (/^## /.test(line)) {
            console.log('');
            console.log('  ' + paint(c.bold, c.magenta, '◆ ') + paint(c.bold, c.white, line.slice(3)));
            prevBlank = false;

        } else if (/^### /.test(line)) {
            console.log('  ' + paint(c.bold, c.cyan, '  > ') + paint(c.bold, c.cyan, line.slice(4)));
            prevBlank = false;

        } else if (/^\|/.test(line)) {
            if (/^[\|\s\-:]+$/.test(line)) continue; // separator row
            const cells = line.split('|').slice(1, -1).map(s => s.trim());
            const isHeader = cells.some(cell => cell.match(/^[A-Z]/)); // heuristic: header row starts uppercase
            const rowColor = isHeader ? (s => paint(c.bold, c.white, s)) : (s => paint(c.dim, c.gray, s));
            console.log(
                '  ' + paint(c.dim, c.gray, '│') + ' ' +
                cells.map((cell, i) => rowColor(pad(cell, i === 0 ? 22 : 12))).join(paint(c.dim, c.gray, ' │ '))
            );
            prevBlank = false;

        } else if (/^- /.test(line)) {
            console.log('  ' + paint(c.bold, c.cyan, '  • ') + renderInline(line.slice(2)));
            prevBlank = false;

        } else if (line.trim() === '') {
            if (!prevBlank) console.log('');
            prevBlank = true;

        } else {
            console.log('  ' + renderInline(line));
            prevBlank = false;
        }
    }

    console.log('');
    console.log(THICK);
}


const activeFlags = [...flags].filter(f =>
    Object.values(SECTION_FLAGS).flat().includes(f)
);
const compact = activeFlags.length > 0;
const filterNote = compact ? gray(`  · showing ${activeFlags.join(' ')}`) : '';

if (!compact) printMd(path.join(__dirname, 'methodology.md'), 'methodology');

console.log('');
console.log(paint(c.bold, c.white, `  ▸ benchmark results`));
console.log(paint(c.bold, c.cyan, `    ${title}`) + filterNote);
console.log(paint(c.dim, c.gray, `    ${runNames.length} run${runNames.length !== 1 ? 's' : ''} · ${outDir}`));

for (const runName of runNames) {
    const elegancePath = path.join(outDir, `elegance-${runName}.json`);
    const nextPath = path.join(outDir, `next-${runName}.json`);

    if (!fs.existsSync(elegancePath) || !fs.existsSync(nextPath)) {
        console.log(red(`  ⚠  Skipping "${runName}" — missing pair\n`));
        continue;
    }

    const e = JSON.parse(fs.readFileSync(elegancePath, 'utf8'));
    const n = JSON.parse(fs.readFileSync(nextPath, 'utf8'));

    printHeader(runName);

    for (const group of GROUPS) {
        if (!showGroup(group.label)) continue;
        printGroup(group.label);
        group.metrics.forEach(metric => printMetric(metric, e, n));
        console.log(HR);
    }

    if (!compact) console.log('');
}

if (!compact) printMd(path.join(outDir, 'test.md'), `test · ${title}`);